package br.com.qaenginner.model;

public class Conta {

	private int saldo;
	private int vlRecarga;

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

	public int getVlRecarga() {
		return vlRecarga;
	}

	public void setVlRecarga(int vlRecarga) {
		this.vlRecarga = vlRecarga;
	}

}
