package br.com.qaenginner.service;

import br.com.qaenginner.model.Cliente;

public class RecargaCelularService {
	
	public void recarregarCelular(Cliente cliente) {
		
		if(cliente.getConta().getSaldo() > cliente.getConta().getVlRecarga()) {
			cliente.getTelefone().setSaldo(cliente.getTelefone().getSaldo() + cliente.getConta().getVlRecarga());
			cliente.getConta().setSaldo(cliente.getConta().getSaldo() - cliente.getConta().getVlRecarga());
		}
	}
}
