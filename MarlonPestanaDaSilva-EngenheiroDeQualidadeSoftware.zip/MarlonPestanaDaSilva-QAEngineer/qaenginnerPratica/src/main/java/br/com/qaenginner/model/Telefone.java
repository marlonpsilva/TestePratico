package br.com.qaenginner.model;

public class Telefone {

	private String numero_linha;
	private int saldo;

	public String getNumero_linha() {
		return numero_linha;
	}

	public void setNumero_linha(String numero_linha) {
		this.numero_linha = numero_linha;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}

}
