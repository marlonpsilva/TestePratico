package br.com.qaenginner.tests;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import br.com.qaenginner.model.Cliente;
import br.com.qaenginner.model.Conta;
import br.com.qaenginner.model.Telefone;
import br.com.qaenginner.service.RecargaCelularService;

public class sampleTests {
	SoftAssert softAssert;
	RecargaCelularService recargaCelularService;
	Cliente cliente;
	Telefone telefone;
	Conta conta;
	
	@BeforeMethod
	public void beforeTest() {
		
		softAssert = new SoftAssert();
		recargaCelularService = new RecargaCelularService();
		cliente = new Cliente();
		telefone = new Telefone();
		conta = new Conta();
		
		cliente.setNome_cliente("Fulano Silva");
		telefone.setNumero_linha("98910991281");
		telefone.setSaldo(15);
	}
	
	@Test
	public void dadoUmNumeroDeTelefoneRealizarRecargaComSaldoDaContaDoCliente() {
		
		conta.setSaldo(200);
		conta.setVlRecarga(30);
		
		cliente.setTelefone(telefone);
		cliente.setConta(conta);
		
		recargaCelularService.recarregarCelular(cliente);
		
		softAssert.assertEquals(cliente.getTelefone().getSaldo(), 45);
		softAssert.assertEquals(cliente.getConta().getSaldo(), 170);
		softAssert.assertAll();
	}

	@Test
	public void dadoUmClienteQuandoSaldoContaZeradoNaoDeveRealizarRecarga() {
		conta.setSaldo(0);
		conta.setVlRecarga(30);
		cliente.setTelefone(telefone);
		cliente.setConta(conta);
		
		recargaCelularService.recarregarCelular(cliente);
		
		softAssert.assertEquals(telefone.getSaldo(), 15);
		softAssert.assertEquals(cliente.getConta().getSaldo(), 0);
		softAssert.assertAll();
		
	}
	
	@Test
	public void dadoUmClienteQuandoSaldoContaMenorQueValorDeRecargaNaoDeveRealizarRecarga() {
	
		conta.setSaldo(15);
		conta.setVlRecarga(30);
		cliente.setTelefone(telefone);
		cliente.setConta(conta);
		
		recargaCelularService.recarregarCelular(cliente);
		
		softAssert.assertEquals(telefone.getSaldo(), 15);
		softAssert.assertEquals(cliente.getConta().getSaldo(), 15);
		softAssert.assertAll();
		
	}
}
