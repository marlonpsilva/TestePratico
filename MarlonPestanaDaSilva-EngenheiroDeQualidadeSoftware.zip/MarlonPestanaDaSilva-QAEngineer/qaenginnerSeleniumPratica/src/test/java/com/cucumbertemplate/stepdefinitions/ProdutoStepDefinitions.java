package com.cucumbertemplate.stepdefinitions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.cucumbertemplate.GlobalParameters;
import com.cucumbertemplate.dbsteps.ProdutosDBSteps;
import com.cucumbertemplate.form.ProdutoForm;
import com.cucumbertemplate.pages.CarrinhoPage;
import com.cucumbertemplate.pages.CheckoutPage;
import com.cucumbertemplate.pages.MainPage;
import com.cucumbertemplate.pages.ProdutoPage;
import com.cucumbertemplate.utils.DriverFactory;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ProdutoStepDefinitions {

	private MainPage mainPage;
	private ProdutoPage produtoPage;
	private ProdutoForm produto;
	private CarrinhoPage carrinho;
	private CheckoutPage checkoutPage;
	
	@Before
	public void DBBeforeScenario() {
		new GlobalParameters();
		produto = new ProdutoForm();
		produto = ProdutosDBSteps.pesquisaProduto();
	}

	@Given("Que acesso o site {string}")
	public void que_estou_no_site(String url) {
		mainPage = new MainPage();
		produtoPage = new ProdutoPage();
		carrinho = new CarrinhoPage();
		checkoutPage = new CheckoutPage();
		DriverFactory.INSTANCE.get(url);
	}

	@When("Clico em Special Offer")
	public void clico_em_special_offer() {
		mainPage.clicandoSpecialOffer();
	}

	@And("Clico em See Offer")
	public void clico_em_see_offer() {
		mainPage.clicandoSeeOffer();
	}

	@Then("Deve mostra nome do produto {string}")
	public void deve_mostra_nome_do_produto(String string) {
		assertEquals(produto.getDescricao(), produtoPage.retornaDescricao());
	}

	@And("Customizacao {string}")
	public void customizacao(String string) {
		assertEquals(produto.getCustomization(), produtoPage.retornaCustomization());
	}

	@And("Display {string}")
	public void display(String string) {
		assertEquals(produto.getDisplay(), produtoPage.retornaDisplay());
	}

	@And("Resolucao {string}")
	public void resolucao(String string) {
		assertEquals(produto.getDisplayResolution(), produtoPage.retornaDisplayResolution());
	}

	@And("Polegadas {string}")
	public void polegadas(String string) {
		assertEquals(produto.getDisplaySize(), produtoPage.retornaDisplaySize());
	}

	@And("Memoria {string}")
	public void memoria(String string) {
		assertEquals(produto.getMemory(), produtoPage.retornaMemory());
	}

	@And("SO {string}")
	public void so(String string) {
		assertEquals(produto.getOperatingSystem(), produtoPage.retornaOperatingSystemField());
	}

	@And("Processador {string}")
	public void processador(String string) {
		assertEquals(produto.getProcessor(), produtoPage.retornaProcessor());
	}

	@And("Touch {string}")
	public void touch(String string) {
		assertEquals(produto.getTouchScreen(), produtoPage.retornaTouchScreen());
	}

	@And("Peso {string}")
	public void peso(String string) {
		assertEquals(produto.getWeight(), produtoPage.retornaWeight());
	}

	@And("Altero a cor do produto para {string}")
	public void altero_a_cor_do_produto_para(String color) {
		produtoPage.clickCorProduto(color);
		ProdutosDBSteps.updateProdutoColor(color);
	}
	
	@And("Altero a cor do produto")
	public void altero_a_cor_do_produto() {
		produtoPage.clickCorProduto(produto.getColor());
	}

	@When("Clico no botão Add to cart")
	public void clico_no_botao_add_to_cart() {
		produtoPage.adicionarNoCarrinho();
	}

	@And("Clico no menu carrinho")
	public void Clico_no_menu_carrinho() {
		mainPage.acessandoCarrinho();
	}

	@Then("Produto deve ser adicionado ao carrinho com a cor")
	public void produto_foi_adicionado_ao_carrinho_com_a_cor_selecionada() {
		String color = carrinho.getProductColor();
		assertEquals(produto.getColor(), color);
	}

	@Given("Abrir pesquisa")
	public void abrir_pesquisa() {
		mainPage.abrirPesquisa();
	}

	@Given("Pesquisar por {string}")
	public void pesquisar_por(String string) {
		mainPage.preencherPesquisaProduto(string);
	}

	@Given("Seleciono produto pesquisado")
	public void seleciono_produto_pesquisado() {
		mainPage.selecionarProduto();
	}

	@And("Altero a quantidade de produtos para 2")
	public void altero_a_quantidade_de_produtos_para_dois() {
		produtoPage.preencherQuantidade();
	}

	@When("Acesso a página de checkout")
	public void acesso_a_pagina_de_checkout() {
		mainPage.acessandoCarrinho();
		mainPage.acessandoCheckout();
	}

	@Then("Soma dos preços deve corresponder ao total de {string}")
	public void soma_dos_precos_deve_corresponder_ao_total(String totalEsperado) {
		String total = checkoutPage.retornandoPrecoProduto();
		assertEquals(totalEsperado, total);

	}

	@Given("Clico no carrinho de compras")
	public void clico_no_carrinho_de_compras() {
		mainPage.acessandoCarrinho();
	}

	@When("Removo produto do carrinho de compras")
	public void removo_produto_do_carrinho_de_compras() {
		carrinho.removerProduto();
	}

	@Then("Carrinho de compras deve está vazio")
	public void carrinho_de_compras_deve_esta_vazio() {
		boolean cartIsEmpty = carrinho.cartIsEmpty();
		assertTrue(cartIsEmpty);
	}

}
