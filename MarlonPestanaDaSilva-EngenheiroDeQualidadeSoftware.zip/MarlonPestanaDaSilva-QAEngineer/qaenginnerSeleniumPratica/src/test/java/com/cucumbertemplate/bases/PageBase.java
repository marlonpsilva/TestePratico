package com.cucumbertemplate.bases;

import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumbertemplate.GlobalParameters;
import com.cucumbertemplate.utils.DriverFactory;

public class PageBase {

	protected WebDriverWait wait = null;
	protected WebDriver driver = null;
	protected JavascriptExecutor javaScriptExecutor = null;

	public PageBase() {
		wait = new WebDriverWait(DriverFactory.INSTANCE, GlobalParameters.TIMEOUT_DEFAULT);
		driver = DriverFactory.INSTANCE;
		javaScriptExecutor = (JavascriptExecutor) driver;
	}

	private void waitUntilPageReady() {
		StopWatch timeOut = new StopWatch();
		timeOut.start();
		while (timeOut.getTime() <= GlobalParameters.TIMEOUT_DEFAULT) {
			String documentState = javaScriptExecutor.executeScript("return document.readyState").toString();
			if (documentState.equals("complete")) {
				timeOut.stop();
				break;
			}
		}
	}

	protected WebElement waitForElement(By locator) {
		waitUntilPageReady();
		wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		WebElement element = driver.findElement(locator);
		return element;
	}
	
	protected WebElement waitForElement(WebElement element) {
		waitUntilPageReady();
		wait.until(ExpectedConditions.elementToBeClickable(element));
		return element;
	}

	protected WebElement waitAttributeContains(By locator, String attribute, String value) {
		WebElement element = driver.findElement(locator);
		wait.until(ExpectedConditions.attributeContains(locator, attribute, value));
		return element;
	}

	protected WebElement waitAttribute(By locator, String attribute) {
		WebElement element = driver.findElement(locator);
		wait.until(ExpectedConditions.attributeToBeNotEmpty(element, attribute));
		return element;
	}

	protected void click(By locator) {
		WebDriverException possibleWebDriverException = null;
		StopWatch timeOut = new StopWatch();
		timeOut.start();

		while (timeOut.getTime() <= GlobalParameters.TIMEOUT_DEFAULT) {
			WebElement element = null;
			try {
				element = waitForElement(locator);
				element.click();
				timeOut.stop();
				return;
			} catch (StaleElementReferenceException e) {
				continue;
			} catch (WebDriverException e) {
				possibleWebDriverException = e;
				if (e.getMessage().contains("Other element would receive the click")) {
					continue;
				}

				throw e;
			}
		}
		try {
			throw new Exception(possibleWebDriverException);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected void click(WebElement element) {
		WebDriverException possibleWebDriverException = null;
		StopWatch timeOut = new StopWatch();
		timeOut.start();

		while (timeOut.getTime() <= GlobalParameters.TIMEOUT_DEFAULT) {
			try {
				element = waitForElement(element);
				element.click();
				timeOut.stop();
				return;
			} catch (StaleElementReferenceException e) {
				continue;
			} catch (WebDriverException e) {
				possibleWebDriverException = e;
				if (e.getMessage().contains("Other element would receive the click")) {
					continue;
				}

				throw e;
			}
		}
		try {
			throw new Exception(possibleWebDriverException);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	protected void sendKeys(By locator, String text) {
		waitForElement(locator).sendKeys(text);	
	}
	
	protected void sendKeysJavaScript(By locator, String value) {
		WebElement element = waitForElement(locator);
		javaScriptExecutor.executeScript("arguments[0].value='" + value + "';", element);
	}

	protected String getText(By locator) {
		String text = waitForElement(locator).getText();
		return text;
	}

	protected String getValue(By locator) {
		String text = waitForElement(locator).getAttribute("value");
		return text;
	}

	protected String getAttribute(By locator, String attribute) {
		waitForElement(locator);
		waitAttribute(locator, attribute);
		String value = driver.findElement(locator).getAttribute(attribute);
		return value;
	}
}
