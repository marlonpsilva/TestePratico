package com.cucumbertemplate.pages;

import org.openqa.selenium.By;

import com.cucumbertemplate.bases.PageBase;

public class CarrinhoPage extends PageBase {
	
	By productColorField = By.className("productColor");
	By menuCheckoutLink = By.id("checkOutButton");
	By removerProdutobutton = By.xpath("//*[@Translate='REMOVE']");
	By cartIsEmpty = By.xpath("//*[@Translate='Your_shopping_cart_is_empty'][@class='roboto-bold ng-scope']");
	
	String colorAttribute= "title";
	String cartIsEmptyText = "Your shopping cart is empty";
	
	public String getProductColor() {
		String color = getAttribute(productColorField, colorAttribute);
		return color;
	}
	
	public void acessandoCheckout() {
		click(menuCheckoutLink);
	}

	public void removerProduto() {
		click(removerProdutobutton);
	}

	public boolean cartIsEmpty() {
		String text = getText(cartIsEmpty);
		boolean result = text.equals(cartIsEmptyText);
		return result;
	}

}
