package com.cucumbertemplate.pages;

import org.openqa.selenium.By;

import com.cucumbertemplate.bases.PageBase;

public class ProdutoPage extends PageBase {
	
	By produtoDescricaoField = By.xpath("//div[@id='Description']/h1");
	By customizationField = By.xpath("//div[1]/label[@class='value ng-binding']");
	By displayField = By.xpath("//div[2]/label[@class='value ng-binding']");
	By displayResolutionField = By.xpath("//div[3]/label[@class='value ng-binding']");
	By displaySizeField = By.xpath("//div[4]/label[@class='value ng-binding']");
	By memoryField = By.xpath("//div[5]/label[@class='value ng-binding']");
	By operatingSystemField = By.xpath("//div[6]/label[@class='value ng-binding']");
	By processorField = By.xpath("//div[7]/label[@class='value ng-binding']");
	By touchScreenField = By.xpath("//div[8]/label[@class='value ng-binding']");
	By weightField = By.xpath("//div[9]/label[@class='value ng-binding']");
	
	By salvaNoCarrinhoButton = By.name("save_to_cart");
		
	By quantidadeField = By.cssSelector(".plus");
	
	protected By colorSelect(String color) {
		return By.xpath("//span[@title='" + color + "'][@id='bunny']");
	}
	
	public String retornaDescricao() {
		return getText(produtoDescricaoField);
	}
	
	public String retornaCustomization() {
		return getText(customizationField);
	}
	
	public String retornaDisplay() {
		return getText(displayField);
	}
	
	public String retornaDisplayResolution() {
		return getText(displayResolutionField);
	}
	
	public String retornaDisplaySize() {
		return getText(displaySizeField);
	}
	
	public String retornaMemory() {
		return getText(memoryField);
	}
	
	public String retornaProcessor() {
		return getText(processorField);
	}
	
	public String retornaOperatingSystemField() {
		return getText(operatingSystemField);
	}
	
	public String retornaTouchScreen() {
		return getText(touchScreenField);
	}
	
	public String retornaWeight() {
		return getText(weightField);
	}
	
	public void clickCorProduto(String color) {
		click(colorSelect(color));
	}
	
	public void adicionarNoCarrinho() {
		click(salvaNoCarrinhoButton);
	}
	
	public void preencherQuantidade() {
		click(quantidadeField);
	}

}
