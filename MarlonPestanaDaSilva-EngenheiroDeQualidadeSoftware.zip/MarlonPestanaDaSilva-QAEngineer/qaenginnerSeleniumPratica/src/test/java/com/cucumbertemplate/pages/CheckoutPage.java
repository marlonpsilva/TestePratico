package com.cucumbertemplate.pages;

import org.openqa.selenium.By;

import com.cucumbertemplate.bases.PageBase;

public class CheckoutPage extends PageBase {
	
	By precoProdutoField = By.xpath("//span[@class='roboto-medium totalValue ng-binding']");

	public String retornandoPrecoProduto() {
		return getText(precoProdutoField);
	}
}
