package com.cucumbertemplate.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cucumbertemplate.GlobalParameters;
import com.cucumbertemplate.form.ProdutoForm;

public class DBUtils {

	private static String getStringConnection() {
		return "jdbc:mysql://" + GlobalParameters.DB_URL + "/" + GlobalParameters.DB_NAME
				+ "?useTimezone=true&serverTimezone=UTC";
	}

	public static void executeUpdateQuery(String query) {

		Connection connection = null;

		try {
			Statement stmt = null;
			connection = DriverManager.getConnection(getStringConnection(), GlobalParameters.DB_USER,
					GlobalParameters.DB_PASSWORD);

			stmt = connection.createStatement();
			stmt.executeUpdate(query);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	//Não ficou legal aqui.
	public static List<ProdutoForm> getQuery(String query) {
		ResultSet rs = null;
		Connection connection = null;
		List<ProdutoForm> produtos = new ArrayList<ProdutoForm>();

		try {

			Statement stmt = null;
			connection = DriverManager.getConnection(getStringConnection(), GlobalParameters.DB_USER,
					GlobalParameters.DB_PASSWORD);

			stmt = connection.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {
				ProdutoForm produto = new ProdutoForm();
				produto.setDescricao(rs.getString("name_product"));
				produto.setCustomization(rs.getString("CUSTOMIZATION"));
				produto.setDisplay(rs.getString("DISPLAY"));
				produto.setDisplayResolution(rs.getString("DISPLAY_RESOLUTION"));
				produto.setDisplaySize(rs.getString("DISPLAY_SIZE"));
				produto.setMemory(rs.getString("MEMORY"));
				produto.setOperatingSystem(rs.getString("OPERATING_SYSTEM"));
				produto.setProcessor(rs.getString("PROCESSOR"));
				produto.setTouchScreen(rs.getString("TOUCHSCREEN"));
				produto.setWeight(rs.getString("WEIGHT"));
				produto.setColor(rs.getString("COLOR"));
				produtos.add(produto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return produtos;
	}

}
