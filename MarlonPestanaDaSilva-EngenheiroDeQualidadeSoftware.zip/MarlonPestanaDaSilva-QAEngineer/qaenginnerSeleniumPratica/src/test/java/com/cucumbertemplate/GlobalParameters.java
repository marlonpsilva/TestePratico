package com.cucumbertemplate;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GlobalParameters {
	
	public static String BROWSER_DEFAULT;
	public static int TIMEOUT_DEFAULT;
	
	public static String DB_NAME = null;
	public static String DB_URL = null;
	public static String DB_PASSWORD = null;
	public static String DB_USER = null;
	
	private Properties properties;
	
	public GlobalParameters() {
		properties = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream("global.properties");
			properties.load(input);
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		BROWSER_DEFAULT = properties.getProperty("browser.default");
		TIMEOUT_DEFAULT = Integer.parseInt(properties.getProperty("timeout.default"));
		DB_NAME = properties.getProperty("db.name");
		DB_URL = properties.getProperty("db.url");
		DB_PASSWORD = properties.getProperty("db.password");
		DB_USER = properties.getProperty("db.user");
	}
}
