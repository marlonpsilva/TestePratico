package com.cucumbertemplate.utils;

import org.openqa.selenium.WebDriver;

import com.cucumbertemplate.GlobalParameters;

public class DriverFactory {
	
	public static WebDriver INSTANCE = null;
	
	public static void createInstance() {
		String browser = GlobalParameters.BROWSER_DEFAULT;
		
		if(browser.equals("chrome")) {
			INSTANCE = Browsers.getChrome();
		}else {
			try {
				throw new Exception("Navegador não encontrado para a automação!");
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void quitInstance() {
		INSTANCE.quit();
		INSTANCE = null;
	}

}
