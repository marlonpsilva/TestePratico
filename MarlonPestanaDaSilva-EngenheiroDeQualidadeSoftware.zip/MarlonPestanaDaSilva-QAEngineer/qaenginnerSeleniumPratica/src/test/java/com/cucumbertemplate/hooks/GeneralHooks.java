package com.cucumbertemplate.hooks;

import com.cucumbertemplate.utils.DriverFactory;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class GeneralHooks {

	@Before
	public void beforeScenario() {
		DriverFactory.createInstance();
		DriverFactory.INSTANCE.manage().window().maximize();
		
	}

	@After
	public void afterScenario() {
		DriverFactory.quitInstance();
	}

}
