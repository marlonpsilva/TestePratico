package com.cucumbertemplate.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Browsers {
	
	public static WebDriver getChrome() {
		ChromeOptions chromeOptions = new ChromeOptions();
//		chromeOptions.addArguments("no-sandbox");
//		chromeOptions.addArguments("--lang=pt-BR");
//		chromeOptions.addArguments("--allow-runnig-insecure-content");
//		chromeOptions.addArguments("download.default_directory", "target/reports/");
		return new ChromeDriver();
	}

}
