package com.cucumbertemplate.pages;

import org.openqa.selenium.By;

import com.cucumbertemplate.bases.PageBase;

public class MainPage extends PageBase {

	By specialOfferLink = By.linkText("SPECIAL OFFER");
	By seeOfferButton = By.id("see_offer_btn");
	By loaderClass = By.className("loader");
	By menuCarrinhoLink = By.id("menuCart");
	By menuSearch = By.id("menuSearch");
	By autoCompleteField = By.id("autoComplete");
	By checkOutButton = By.id("checkOutButton");
	By productSearchSelect = By.xpath("//*[@id='output']//*[@src='/catalog/fetchImage?image_id=1300']");

	public void clicandoSpecialOffer() {
		waitAttributeContains(loaderClass, "style", "display: none; opacity: 0;");
		click(specialOfferLink);
	}

	public void clicandoSeeOffer() {
		// débito técnico
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(seeOfferButton);
	}

	public void acessandoCarrinho() {
		click(menuCarrinhoLink);
	}

	public void preencherPesquisaProduto(String text) {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sendKeys(autoCompleteField, text);
	}

	public void selecionarProduto() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(productSearchSelect);
	}

	public void acessandoCheckout() {
		click(checkOutButton);

	}

	public void abrirPesquisa() {
		click(menuSearch);
	}
}
