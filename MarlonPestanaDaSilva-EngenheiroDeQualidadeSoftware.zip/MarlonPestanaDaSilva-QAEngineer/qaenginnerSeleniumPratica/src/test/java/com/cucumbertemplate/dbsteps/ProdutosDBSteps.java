package com.cucumbertemplate.dbsteps;

import java.util.List;

import com.cucumbertemplate.form.ProdutoForm;
import com.cucumbertemplate.utils.DBUtils;
import com.cucumbertemplate.utils.Utils;

public class ProdutosDBSteps {

	private static String queriesPath = "src/test/java/com/cucumbertemplate/queries/";
	private static ProdutoForm produto;

	public static ProdutoForm pesquisaProduto() {
		String query = Utils.readFileToAString(queriesPath + "retornaDadosProdutoQuery.sql");
		List<ProdutoForm> produtos = DBUtils.getQuery(query);
		produto = produtos.get(0);

		return produto;
	}
	
	public static void updateProdutoColor(String color) {
		String query = Utils.readFileToAString(queriesPath + "updateColorProdutosQuery.sql");
		query = query.replace("$color", color);
		DBUtils.executeUpdateQuery(query);
	}
}
